from machine import Pin, I2C
import time
import ssd1306


TRIG = Pin(14, Pin.OUT)
ECHO = Pin(15, Pin.IN)


i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=400000)
oled = ssd1306.SSD1306_I2C(128, 64, i2c)

def measure_distance():
    TRIG.low()
    time.sleep_us(2)
    TRIG.high()
    time.sleep_us(10)
    TRIG.low()

    timeout = time.ticks_us()
    while ECHO.value() == 0:
        if time.ticks_diff(time.ticks_us(), timeout) > 30000:
            return None

    pulse_start = time.ticks_us()

    while ECHO.value() == 1:
        if time.ticks_diff(time.ticks_us(), pulse_start) > 30000:
            return None

    pulse_end = time.ticks_us()

    duration = time.ticks_diff(pulse_end, pulse_start)
    distance = duration / 58
    return round(distance, 1)

while True:
    dist = measure_distance()

    oled.fill(0)
    oled.text("Distance", 0, 0)
    oled.hline(0, 12, 128, 1)

    if dist is None:
        oled.text("Too far", 10, 30)
    elif dist < 2 or dist > 400:
        oled.text("Like, that far away?", 10, 30)
    else:
        oled.text(f"{dist} cm", 30, 28)

    oled.show()
    time.sleep(0.2)